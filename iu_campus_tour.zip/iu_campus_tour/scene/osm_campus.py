"""Dựng cảnh từ dữ liệu OpenStreetMap (assets/data/campus_osm.json do tools/fetch_osm.py tạo).

Thứ tự ưu tiên khi quyết định một tòa nhà cao bao nhiêu / mặt tiền gì:
    1. assets/data/building_overrides.json  (theo id OSM hoặc theo tên)  <- bạn chỉnh tay, đáng tin nhất
    2. thẻ OSM (building:levels, height)
    3. mặc định (nhỏ -> 1 tầng, còn lại -> 2 tầng)
Đây là dữ liệu ước lượng: tòa nào chưa có số tầng thật sẽ dùng mặc định, nhớ bổ sung vào overrides.
"""

import json
import math

import numpy as np

import config
from graphics.extrude import extrude_arrays, signed_area
from graphics.mesh import Mesh, create_box
from graphics.procedural_textures import (facade_texture, ground_texture as make_ground_texture, FLOOR_H, TILE_W,
                                          GRASS_TILE, ASPHALT_TILE, MARKED_TILE, PAVING_TILE, CONCRETE_TILE)
from graphics.roads import polyline_strip, polygon_flat, merge_meshes
from scene.geometry2d import rings_to_edges, circle_hits_rings
from scene.scene import Scene, SceneObject

DATA_DIR = getattr(config, "DATA_DIR", config.ASSET_DIR / "data")
# Đường/lối đi trải trên mặt đất: loại OSM -> (texture, bề rộng m, độ cao y, tile m, texture_full_width)
# Đường to nằm thấp hơn đường nhỏ hơn một chút (vài cm) để chỗ giao nhau không bị nhấp nháy (z-fighting).
ROAD_STYLE = {
    "tertiary":      ("asphalt_marked", 7.5, 0.030, MARKED_TILE, True),
    "tertiary_link": ("asphalt_marked", 5.0, 0.032, MARKED_TILE, True),
    "residential":   ("asphalt",        6.0, 0.034, ASPHALT_TILE, False),
    "unclassified":  ("asphalt",        5.0, 0.036, ASPHALT_TILE, False),
    "service":       ("asphalt",        4.5, 0.040, ASPHALT_TILE, False),
    "track":         ("concrete",       3.0, 0.045, CONCRETE_TILE, False),
    "cycleway":      ("asphalt",        2.5, 0.050, ASPHALT_TILE, False),
    "pedestrian":    ("paving",         4.0, 0.055, PAVING_TILE, False),
    "footway":       ("paving",         2.0, 0.060, PAVING_TILE, False),
    "path":          ("paving",         1.5, 0.062, PAVING_TILE, False),
}
PARKING_Y = 0.040
ROAD_MARGIN = 300.0                                  # m: chỉ vẽ đường trong khung các tòa nhà + lề này
RAISED_MIN = 2.5                                     # m: khối nâng cao hơn mức này (cầu nối) không cản đường đi bộ
ROOF_ONLY_KINDS = {"roof", "carport", "canopy"}      # Mái che: chỉ có tấm mái, đi xuyên qua được
SPAWN_CLEARANCE = 6.0                                # m: điểm xuất phát cách tòa nhà tối thiểu


def _norm(s):
    return " ".join(str(s).casefold().split())


def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_overrides(path):
    """Đọc building_overrides.json; chuẩn hóa tên (không phân biệt hoa thường). Thiếu file -> rỗng."""
    if not path.exists():
        return {"by_name": {}, "by_id": {}}
    raw = load_json(path)
    return {"by_name": {_norm(k): v for k, v in raw.get("by_name", {}).items()},
            "by_id": raw.get("by_id", {})}


def _polygon_area(ring):
    return abs(signed_area(ring))


def resolve_style(b, overrides):
    """Quyết định kiểu cho một tòa nhà từ override / thẻ OSM / mặc định."""
    kind = (b.get("kind") or "yes").lower()
    name = b.get("name") or ""
    ov = {}
    ov.update(overrides["by_name"].get(_norm(name), {}))
    if b.get("name_en"):
        ov = {**overrides["by_name"].get(_norm(b["name_en"]), {}), **ov}
    ov.update(overrides["by_id"].get(b.get("id", ""), {}))

    roof_only = ov.get("roof_only", kind in ROOF_ONLY_KINDS)
    under_construction = ("xây dựng" in name.casefold()) or ("construction" in name.casefold()) \
        or kind == "construction"

    levels = ov.get("levels") or b.get("levels")
    height = ov.get("height") or b.get("height")
    if height is None:
        if roof_only:
            height = 3.5
        else:
            if levels is None:
                levels = 3 if under_construction else (1 if _polygon_area(b["outer"]) < 40 else 2)
            height = float(levels) * FLOOR_H
    levels = levels if levels is not None else max(1, round(height / FLOOR_H))

    facade = ov.get("facade") or ("concrete" if under_construction else "plain")

    # Khối nâng lên (cầu nối, mái đua): bắt đầu từ tầng min_levels thay vì từ mặt đất.
    # Quy ước: "tầng 1" là tầng trệt, nên cầu nối nằm ở tầng 3-4 có min_levels = 2, levels = 4.
    base = float(ov["min_height"]) if ov.get("min_height") else float(ov.get("min_levels") or 0) * FLOOR_H
    base = min(base, float(height) - 0.5) if base else 0.0
    return {
        "levels": levels, "height": float(height), "base": base, "facade": facade,
        "facade_by_side": ov.get("facade_by_side"),          # {"N": "maroon", "S": "white", ...}
        "roof_only": bool(roof_only),
        "collidable": bool(ov.get("collidable", not roof_only)),
        "skip": bool(ov.get("skip", False)),
    }


def _make_object(mesh, texture, position=(0, 0, 0), cast_shadow=True, collidable=False,
                 specular=0.10, shininess=32.0):
    """Tạo SceneObject rồi gán thuộc tính sau (chạy được với cả bản SceneObject cũ lẫn mới)."""
    obj = SceneObject(mesh, texture, position=position)
    obj.cast_shadow, obj.collidable = cast_shadow, collidable
    obj.specular, obj.shininess = specular, shininess
    return obj


def find_spawn(data, collider_edges):
    """Điểm xuất phát: phía nam khu nhà, cách mọi tòa >= SPAWN_CLEARANCE; nhìn về giữa khu nhà."""
    pts = np.array([p for b in data["buildings"] for p in b["outer"]], dtype=np.float64)
    if len(pts) == 0:
        return (0.0, 15.0), -90.0
    cx, cz = (pts.min(axis=0) + pts.max(axis=0)) / 2          # Tâm hộp bao (không dùng trung bình đỉnh: lệch về tòa nhiều đỉnh)
    start = np.array([cx, pts[:, 1].max() + 10.0])
    candidates = [start]
    for r in np.arange(6.0, 400.0, 6.0):
        for a in np.radians(np.arange(0, 360, 20)):
            candidates.append(start + r * np.array([math.cos(a), math.sin(a)]))
    for c in candidates:
        if not any(circle_hits_rings(c[0], c[1], SPAWN_CLEARANCE, e) for e in collider_edges):
            yaw = math.degrees(math.atan2(cz - c[1], cx - c[0]))
            return (float(c[0]), float(c[1])), yaw
    return (float(start[0]), float(start[1])), -90.0


def add_ground_layers(scene, data, bounds):
    """Trải đường, lối đi và bãi xe lên mặt đất. Gộp theo texture -> chỉ vài draw call dù có hàng trăm đường."""
    x0, z0, x1, z1 = bounds
    inside = lambda pts: any(x0 <= p[0] <= x1 and z0 <= p[1] <= z1 for p in pts)
    groups, count = {}, 0
    for k, r in enumerate(data.get("roads", [])):
        style = ROAD_STYLE.get(r.get("kind"))
        if style is None or not inside(r["points"]):
            continue
        tex_kind, width, y, tile, full = style
        pts = r["points"]
        closed = len(pts) > 3 and pts[0] == pts[-1]
        # Mỗi đường lệch độ cao thêm vài phần nghìn mét: các đường CÙNG loại chồng nhau ở ngã ba không tranh chấp độ sâu
        part = polyline_strip(pts, width, y + 0.0015 * (k % 6), tile, full_width=full, closed=closed)
        if part is not None:
            groups.setdefault(tex_kind, []).append(part)
            count += 1
    for pk in data.get("parking", []):
        if inside(pk["ring"]):
            part = polygon_flat(pk["ring"], PARKING_Y, CONCRETE_TILE)
            if part is not None:
                groups.setdefault("concrete", []).append(part)
                count += 1
    for tex_kind, parts in groups.items():
        v, i = merge_meshes(parts)
        scene.add(_make_object(Mesh(v, i), make_ground_texture(tex_kind), cast_shadow=False,
                               collidable=False, specular=0.02, shininess=8.0))
    return count, len(groups)


def build_campus_from_osm(data, overrides=None, ground_texture=None, tour_spec=None):
    overrides = overrides or {"by_name": {}, "by_id": {}}
    scene = Scene()

    # Chỉ các tòa KHÔNG bị skip mới tính vào cảnh, kích thước mặt đất và điểm xuất phát
    # (tòa ngoài khuôn viên bị skip không được làm lệch các tính toán này).
    active = [b for b in data["buildings"] if not resolve_style(b, overrides)["skip"]]

    extent = max([abs(c) for b in active for p in b["outer"] for c in p] + [100.0])
    G = 2.0 * (extent + 250.0)                            # Mặt đất rộng hơn khu nhà rất nhiều
    # Mặt đất: ảnh cỏ thật (ground.jpg) nếu có, không thì texture cỏ sinh bằng code (liền mạch, ô 8 m)
    scene.add(_make_object(create_box((G, 0.2, G), tex_size=GRASS_TILE),
                           ground_texture if ground_texture is not None else make_ground_texture("grass"),
                           position=(0, -0.1, 0), cast_shadow=False, collidable=False,
                           specular=0.02, shininess=8.0))

    roof_tex = facade_texture("roof")
    collider_edges, report, n_walls = [], [], 0
    obstacle_edges = []                                    # Tường tòa nhà mà tuyến tour phải tránh (cầu nối nâng cao thì không)
    for b in sorted(active, key=lambda b: -_polygon_area(b["outer"])):
        st = resolve_style(b, overrides)
        try:
            geo = extrude_arrays(b["outer"], b.get("holes"), st["height"], TILE_W, FLOOR_H,
                                 kind_of_side=st["facade_by_side"], default_kind=st["facade"],
                                 roof_only=st["roof_only"], base=st["base"])
        except ValueError as e:
            report.append(f"  bỏ qua {b.get('id')}: {e}")
            continue

        rings = [b["outer"]] + [h for h in (b.get("holes") or [])]
        edges = rings_to_edges(rings)
        if st["base"] < RAISED_MIN and not st["roof_only"]:
            obstacle_edges.append(edges)
        xs, zs = np.array(b["outer"])[:, 0], np.array(b["outer"])[:, 1]
        primary = True
        for kind, (v, i) in geo["walls"].items():
            obj = _make_object(Mesh(v, i), facade_texture(kind), collidable=st["collidable"] and primary,
                               specular=0.12)
            if obj.collidable:
                # Hộp bao CẢ tòa nhà (đủ chiều cao) cho pha rộng; pha hẹp dùng đường viền thật
                # (khối nâng lên: đáy hộp ở y = base nên người chơi đi bên dưới được)
                obj.aabb_min = np.array([xs.min(), st["base"], zs.min()], dtype=np.float32)
                obj.aabb_max = np.array([xs.max(), st["height"], zs.max()], dtype=np.float32)
                obj.footprint_edges = edges
                collider_edges.append(edges)
            scene.add(obj)
            primary = False
            n_walls += 1
        rv, ri = geo["roof"]
        scene.add(_make_object(Mesh(rv, ri), roof_tex, specular=0.05))
        if geo["bottom"] is not None:                      # Mặt dưới của khối nâng lên
            bv, bi = geo["bottom"]
            scene.add(_make_object(Mesh(bv, bi), roof_tex, specular=0.02))

        label = b.get("name") or b.get("id")
        if geo["forced"] or geo["holes_ignored"]:
            report.append(f"  {label}: " + ("có lỗ/sân trong (mái phủ kín lỗ) " if geo["holes_ignored"] else "")
                          + (f"{geo['forced']} lần cắt tai ép (đường viền suy biến)" if geo["forced"] else ""))

    # Đường và lối đi trên mặt đất
    all_pts = np.array([p for b in active for p in b["outer"]], dtype=np.float64)
    if len(all_pts):
        lo, hi = all_pts.min(axis=0) - ROAD_MARGIN, all_pts.max(axis=0) + ROAD_MARGIN
        n_roads, n_groups = add_ground_layers(scene, data, (lo[0], lo[1], hi[0], hi[1]))
        print(f"[OSM] đã trải {n_roads} đường/lối đi/bãi xe ({n_groups} nhóm texture)")

    # Tuyến tour tự động theo đường (nếu có tour.json)
    scene.tour_waypoints, scene.tour_info = None, None
    if tour_spec:
        try:
            from scene.tour_route import build_tour
            tour = build_tour(data.get("roads", []), tour_spec, obstacle_edges,
                              eye_height=getattr(config, "EYE_HEIGHT", 1.7))
            scene.tour_waypoints, scene.tour_info = tour["waypoints"], tour
            speed = getattr(config, "TOUR_SPEED", 3.5)
            print(f"[Tour] {len(tour['waypoints'])} waypoint, dài {tour['length']:.0f} m "
                  f"(~{tour['length'] / speed / 60:.1f} phút ở {speed} m/s), cách tường tối thiểu {tour['clearance']:.1f} m")
            for w in tour["warnings"]:
                print("[Tour] cảnh báo:", w)
        except Exception as e:
            import traceback
            print(f"[Tour] Không dựng được tuyến tự động ({e}) -> dùng config.TOUR_WAYPOINTS:")
            traceback.print_exc()

    (sx, sz), yaw = find_spawn({"buildings": active}, collider_edges)
    scene.spawn_pos = (sx, config.EYE_HEIGHT, sz)
    scene.spawn_yaw = yaw
    print(f"[OSM] {len(active)}/{len(data['buildings'])} tòa nhà (đã bỏ {len(data['buildings']) - len(active)} tòa skip) -> {len(scene.objects)} vật thể "
          f"({n_walls} nhóm tường); điểm xuất phát ({sx:.1f}, {sz:.1f})")
    for line in report:
        print("[OSM] cảnh báo:" + line)
    return scene
